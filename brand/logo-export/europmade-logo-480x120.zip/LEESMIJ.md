# EuropMade — logo 480 × 120 px

Vier bestanden, elk als SVG, PNG en WebP.

| Bestand | Letter | Achtergrond |
|---|---|---|
| `europmade-boog-480x120.*` | boog | transparant |
| `europmade-boog-negatief-480x120.*` | boog | diepblauw, logo wit |
| `europmade-strak-480x120.*` | strak | transparant |
| `europmade-strak-negatief-480x120.*` | strak | diepblauw, logo wit |

## Opbouw van het canvas

Het canvas is 480 × 120 px (4:1). Het logo zelf is 5,27:1 en is dus **niet uitgerekt**,
maar op schaal in het canvas gezet:

- logo: 432 × 82 px, schaalfactor 1,2819
- gecentreerd, met 24 px marge links en rechts en circa 19 px boven en onder

Die marge is meteen de vrije ruimte van het merk: houd hem aan waar je het logo ook plaatst.

Zie `KLEURCODES.md` voor de kleuren.
