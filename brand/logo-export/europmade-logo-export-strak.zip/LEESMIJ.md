# EuropMade — logo-export (strak-variant)

Twee versies, elk in SVG, PNG en WebP.

| Bestand | Wat |
|---|---|
| `europmade-logo-strak-mono.*` | positief — diepblauw `#10396B` op een **transparante** achtergrond |
| `europmade-logo-strak-negatief.*` | negatief — wit logo op een gevuld diepblauw vlak |

## Formaten

- **SVG** — vector, oneindig schaalbaar. Gebruik dit overal waar het kan: website, drukwerk, Office.
- **PNG** — transparant (positief) of met blauw vlak (negatief), in 400, 1200 en 2400 px breed.
- **WebP** — lossless, ongeveer een derde van de PNG-bestandsgrootte. Voor de website.

Maatkeuze: 400 px voor een header of e-mailhandtekening, 1200 px voor presentaties en social,
2400 px voor drukwerk en grote schermen.

## Vrije ruimte

In het negatief zit al een marge van 25% van de beeldmerkhoogte rondom. Houd bij het positief
dezelfde marge aan: minimaal een kwart beeldmerkhoogte vrij aan alle kanten.

## Let op

- Het positief is transparant. Zet het alleen op lichte achtergronden; op donker gebruik je het negatief.
- Letters zijn omgezet naar paden; er is geen lettertype nodig.
